import { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import FeaturesPage from "./pages/FeaturesPage";
import Auth from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import { auth } from "./firebase";
import { onAuthStateChanged, User } from "firebase/auth";
import { motion, AnimatePresence } from "framer-motion";

function Particles() {
  const [particles, setParticles] = useState<any[]>([]);

  useEffect(() => {
    const colors = ['#FFD700', '#FF2020', '#FFA500'];
    const newParticles = Array.from({ length: 30 }).map((_, i) => {
      const s = 2 + Math.random() * 4;
      return {
        id: i,
        size: s,
        color: colors[Math.floor(Math.random() * colors.length)],
        left: Math.random() * 100,
        duration: 12 + Math.random() * 18,
        delay: -(Math.random() * 20),
        opacity: 0.3 + Math.random() * 0.4
      };
    });
    setParticles(newParticles);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-[1] overflow-hidden">
      {particles.map(p => (
        <div
          key={p.id}
          className="absolute rounded-full"
          style={{
            width: `${p.size}px`,
            height: `${p.size}px`,
            background: p.color,
            left: `${p.left}vw`,
            animation: `ptDrift ${p.duration}s linear infinite`,
            animationDelay: `${p.delay}s`,
            opacity: p.opacity,
            boxShadow: `0 0 ${p.size * 2}px ${p.color}`
          }}
        />
      ))}
    </div>
  );
}

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [user, setUser] = useState<User | null>(null);
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (usr) => {
      setUser(usr);
      setInitialized(true);
      if (usr && (currentPage === 'auth' || currentPage === 'home')) {
        setCurrentPage('dashboard');
      }
    });
    return unsub;
  }, []);

  if (!initialized) return null;

  return (
    <>
      <Navbar onNavigate={setCurrentPage} user={user} />
      
      {/* Backgrounds */}
      <div className="aurora" />
      <div className="grid-overlay" />
      <div className="noise-overlay" />
      <Particles />

      {/* Page Content */}
      <AnimatePresence mode="wait">
        <motion.div
           key={currentPage}
           initial={{ opacity: 0, y: 20 }}
           animate={{ opacity: 1, y: 0 }}
           exit={{ opacity: 0, y: -20 }}
           transition={{ duration: 0.3 }}
           className="min-h-screen"
        >
          {currentPage === 'home' && <Home onNavigate={setCurrentPage} />}
          {currentPage === 'features' && <FeaturesPage />}
          {currentPage === 'auth' && <Auth onNavigate={setCurrentPage} />}
          {currentPage === 'dashboard' && <Dashboard onNavigate={setCurrentPage} />}
        </motion.div>
      </AnimatePresence>
    </>
  );
}

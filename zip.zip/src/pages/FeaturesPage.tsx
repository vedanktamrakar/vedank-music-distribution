import { motion } from "framer-motion";
import { BadgeCheck } from "lucide-react";

export default function FeaturesPage() {
  const features = [
    "Unlimited Release",
    "Unlimited Artists",
    "Unlimited Record Label",
    "Unlimited Video Release",
    "Unlimited Callertune Cuts",
    "YouTube Official Artist Channel",
    "Keep 100% ownership",
    "Advanced analytics & reporting",
    "Priority email Support",
    "Priority release processing",
    "Sync licensing (TV, movies, commercials, video games)",
    "Keep Yours 100% Royalties",
    "Dolby Atmos distribution",
    "Access to all upcoming features",
    "Monetize UGC on Meta, TikTok, and YouTube",
    "On-demand royalty payouts",
    "YouTube Content ID",
    "Meta Content ID",
    "Fast Delivery",
    "Music video distribution to VEVO, Apple Music, Tidal, and more",
    "lifetime song Ability",
    "Facebook & Instagram Whitelisting",
    "Transparent Royalties Reports",
    "Spotify Verification",
    "Jio Saavan Verification",
    "Bomplay Verification",
    "Lyrics Distribution"
  ];

  return (
    <div className="relative z-10 pt-24 px-4 md:px-8 pb-20 max-w-7xl mx-auto min-h-screen">
      <div className="text-center mb-16 mt-8">
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="font-display text-4xl md:text-6xl tracking-widest text-[#FFD700]"
        >
          EXCLUSIVE <span className="text-[#E8001E]">FEATURES</span>
        </motion.h1>
        <div className="w-24 h-1 mx-auto mt-4 bg-gradient-to-r from-transparent via-[#FFD700] to-transparent" />
        <p className="mt-4 font-[Orbitron] text-xs md:text-sm tracking-widest text-white/50 uppercase">
          Everything you need to distribute globally
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 perspective-[1000px]">
        {features.map((feature, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0.9, rotateX: 30 }}
            animate={{ 
              opacity: 1, 
              scale: 1, 
              rotateX: 0,
              y: [0, -8, 0]
            }}
            transition={{
              opacity: { duration: 0.5, delay: i * 0.05 },
              scale: { duration: 0.5, delay: i * 0.05 },
              rotateX: { duration: 0.5, delay: i * 0.05 },
              y: {
                repeat: Infinity,
                duration: 4,
                delay: (i % 5) * 0.4,
                ease: "easeInOut"
              }
            }}
            className="flex items-center gap-4 bg-white/5 border border-[#FFD700]/20 rounded-xl p-5 hover:bg-white/10 hover:border-[#FFD700]/50 transition-colors shadow-[0_0_20px_rgba(255,215,0,0.05)] hover:shadow-[0_0_30px_rgba(255,215,0,0.15)] preserve-3d"
          >
            <div className="flex-shrink-0">
              <BadgeCheck className="w-6 h-6 text-blue-500 drop-shadow-[0_0_8px_rgba(59,130,246,0.6)]" />
            </div>
            <span className="font-sans text-sm md:text-base font-medium text-white/90">
              {feature}
            </span>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

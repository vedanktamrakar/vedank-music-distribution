import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, signInWithPopup, sendPasswordResetEmail, updateProfile } from "firebase/auth";
import { auth, googleProvider } from "../firebase";

export default function Auth({ onNavigate }: { onNavigate: (p: string) => void }) {
  const [tab, setTab] = useState<'login' | 'signup' | 'forgot'>('login');
  const [msg, setMsg] = useState<{ text: string, type: 'error' | 'success' } | null>(null);
  const [loading, setLoading] = useState(false);

  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const [name, setName] = useState('');

  const friendlyError = (code: string) => {
    const map: Record<string, string> = {
      'auth/user-not-found':       'No account found with this email.',
      'auth/wrong-password':       'Incorrect password. Try again.',
      'auth/email-already-in-use': 'This email is already registered.',
      'auth/invalid-email':        'Invalid email address.',
      'auth/weak-password':        'Password is too weak.',
      'auth/too-many-requests':    'Too many attempts. Please try later.',
      'auth/network-request-failed': 'Network error. Check your connection.',
      'auth/invalid-credential':   'Email or password is incorrect.',
    };
    return map[code] || 'Something went wrong. Please try again.';
  };

  const handleAction = async () => {
    setMsg(null);
    if (!email || (tab !== 'forgot' && !pass)) return setMsg({ text: 'Please fill all fields.', type: 'error' });
    if (tab === 'signup' && !name) return setMsg({ text: 'Please fill all fields.', type: 'error' });
    if (tab === 'signup' && pass.length < 6) return setMsg({ text: 'Password must be at least 6 characters.', type: 'error' });

    setLoading(true);
    try {
      if (tab === 'login') {
        await signInWithEmailAndPassword(auth, email, pass);
        setMsg({ text: '✅ Login successful!', type: 'success' });
      } else if (tab === 'signup') {
        const cred = await createUserWithEmailAndPassword(auth, email, pass);
        await updateProfile(cred.user, { displayName: name });
        setMsg({ text: '🎉 Account created!', type: 'success' });
      } else if (tab === 'forgot') {
        await sendPasswordResetEmail(auth, email);
        setMsg({ text: '📧 Reset link sent!', type: 'success' });
      }
    } catch (e: any) {
      setMsg({ text: friendlyError(e.code), type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  const doGoogle = async () => {
    setMsg(null);
    setLoading(true);
    try {
      await signInWithPopup(auth, googleProvider);
      setMsg({ text: '✅ Login successful!', type: 'success' });
    } catch (e: any) {
      if (e.code !== 'auth/popup-closed-by-user') {
        setMsg({ text: friendlyError(e.code), type: 'error' });
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative z-10 min-h-screen flex items-center justify-center p-4 pt-20">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-[420px] bg-[#0A0A0E]/85 border border-[#FFD700]/20 rounded-[28px] p-9 backdrop-blur-xl shadow-[0_0_60px_rgba(255,215,0,0.06),0_0_0_1px_rgba(255,255,255,0.04)] relative"
      >
        {/* Animated Line */}
        <div className="absolute top-0 left-[20%] right-[20%] h-[2px] rounded-full bg-gradient-to-r from-transparent via-[#FFD700] to-transparent bg-[length:200%_100%] animate-[topLine_3s_linear_infinite]" />

        <div className="text-center mb-7">
          <div className="font-display text-[26px] font-black mb-1">
            <span className="text-[#FFD700] drop-shadow-[0_0_20px_rgba(255,215,0,0.5)]">VEDANK</span>{" "}
            <span className="text-[#FF2020] drop-shadow-[0_0_20px_rgba(255,32,32,0.5)]">MUSIC</span>
          </div>
          <div className="font-[Orbitron] text-[10px] tracking-[4px] text-white/30">OFFICIAL PORTAL</div>
        </div>

        {tab !== 'forgot' && (
          <div className="flex bg-white/5 rounded-2xl p-1 mb-7 gap-1">
            <button 
              onClick={() => setTab('login')} 
              className={`flex-1 py-2.5 rounded-xl font-[Orbitron] text-[11px] tracking-[2px] transition-all ${tab === 'login' ? 'bg-gradient-to-br from-[#FFD700]/15 to-[#FF2020]/10 text-[#FFD700] shadow-[0_0_15px_rgba(255,215,0,0.1)]' : 'text-white/40 hover:text-white/70'}`}
            >
              LOGIN
            </button>
            <button 
              onClick={() => setTab('signup')} 
              className={`flex-1 py-2.5 rounded-xl font-[Orbitron] text-[11px] tracking-[2px] transition-all ${tab === 'signup' ? 'bg-gradient-to-br from-[#FFD700]/15 to-[#FF2020]/10 text-[#FFD700] shadow-[0_0_15px_rgba(255,215,0,0.1)]' : 'text-white/40 hover:text-white/70'}`}
            >
              SIGN UP
            </button>
          </div>
        )}

        <AnimatePresence mode="wait">
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="flex flex-col gap-4"
          >
            {msg && (
              <div className={`p-3 rounded-xl text-sm font-semibold text-center ${msg.type === 'error' ? 'bg-[#FF2020]/10 border border-[#FF2020]/30 text-[#ff6b6b]' : 'bg-[#FFD700]/10 border border-[#FFD700]/30 text-[#FFD700]'}`}>
                {msg.text}
              </div>
            )}

            {tab === 'forgot' && (
              <p className="text-sm text-white/50 text-center mb-1 leading-relaxed">
                Enter your email and we'll send you a password reset link.
              </p>
            )}

            {tab === 'signup' && (
              <div className="flex flex-col relative group">
                <label className="font-[Orbitron] text-[10px] tracking-[3px] text-[#FFD700]/60 mb-2">FULL NAME</label>
                <input 
                  type="text" 
                  value={name} onChange={e => setName(e.target.value)}
                  placeholder="Your Name" 
                  className="w-full bg-white/5 border border-[#FFD700]/20 rounded-xl px-4 py-3.5 text-white font-sans text-base font-semibold outline-none transition-all focus:border-[#FFD700]/50 mx-0 mt-0 mb-0 focus:shadow-[0_0_20px_rgba(255,215,0,0.1)] placeholder-white/20 hover:bg-white/10 input-transition"
                />
              </div>
            )}

            <div className="flex flex-col relative group">
              <label className="font-[Orbitron] text-[10px] tracking-[3px] text-[#FFD700]/60 mb-2">EMAIL ADDRESS</label>
              <input 
                type="email" 
                value={email} onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com" 
                className="w-full bg-white/5 border border-[#FFD700]/20 rounded-xl px-4 py-3.5 text-white font-sans text-base font-semibold outline-none transition-all focus:border-[#FFD700]/50 mx-0 mt-0 mb-0 focus:shadow-[0_0_20px_rgba(255,215,0,0.1)] placeholder-white/20 hover:bg-white/10 input-transition"
              />
            </div>

            {tab !== 'forgot' && (
              <div className="flex flex-col relative group">
                <label className="font-[Orbitron] text-[10px] tracking-[3px] text-[#FFD700]/60 mb-2">PASSWORD</label>
                <input 
                  type="password" 
                  value={pass} onChange={e => setPass(e.target.value)}
                  placeholder={tab === 'signup' ? "Min 6 characters" : "••••••••"} 
                  className="w-full bg-white/5 border border-[#FFD700]/20 rounded-xl px-4 py-3.5 text-white font-sans text-base font-semibold outline-none transition-all focus:border-[#FFD700]/50 mx-0 mt-0 mb-0 focus:shadow-[0_0_20px_rgba(255,215,0,0.1)] placeholder-white/20 hover:bg-white/10 input-transition"
                />
              </div>
            )}

            {tab === 'login' && (
              <div className="text-right -mt-2 mb-1">
                <button onClick={() => setTab('forgot')} className="text-[13px] text-[#FFD700]/50 hover:text-[#FFD700] transition-colors">Forgot password?</button>
              </div>
            )}

            <button 
              onClick={handleAction}
              disabled={loading}
              className="w-full py-4 mt-2 border-none rounded-xl bg-gradient-to-br from-[#c9a000] to-[#FF2020] text-white font-[Orbitron] text-[13px] font-bold tracking-[3px] relative overflow-hidden transition-all hover:-translate-y-0.5 hover:shadow-[0_8px_30px_rgba(255,215,0,0.25)] active:translate-y-0 disabled:opacity-60 disabled:cursor-not-allowed group"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              {loading ? <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin align-middle mr-2" /> : null}
              {tab === 'login' ? 'LOGIN' : tab === 'signup' ? 'CREATE ACCOUNT' : 'SEND RESET LINK'}
            </button>

            {tab !== 'forgot' && (
              <>
                <div className="flex items-center gap-3 my-2 text-white/20 text-xs tracking-[2px] before:flex-1 before:h-px before:bg-white/10 after:flex-1 after:h-px after:bg-white/10">
                  OR
                </div>

                <button 
                  onClick={doGoogle}
                  disabled={loading}
                  className="w-full flex items-center justify-center gap-2.5 p-3.5 border border-white/10 rounded-xl bg-white/5 text-white font-sans font-bold text-[15px] transition-all hover:bg-white/10 hover:border-white/25 hover:-translate-y-0.5 tracking-wide disabled:opacity-60"
                >
                  <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.611 20.083H42V20H24v8h11.303C33.977 32.411 29.464 35 24 35c-6.065 0-11-4.935-11-11s4.935-11 11-11c2.804 0 5.354 1.063 7.281 2.793l5.658-5.657C33.276 7.243 28.842 5 24 5 13.507 5 5 13.507 5 24s8.507 19 19 19c10.998 0 19-7.999 19-19 0-1.295-.138-2.558-.389-3.917z"/><path fill="#FF3D00" d="M6.306 14.691l6.571 4.819C14.655 15.108 18.961 12 24 12c2.804 0 5.354 1.063 7.281 2.793l5.658-5.657C33.276 7.243 28.842 5 24 5 16.318 5 9.656 9.341 6.306 14.691z"/><path fill="#4CAF50" d="M24 43c4.728 0 9.06-1.694 12.35-4.48l-6.19-5.238C28.348 34.524 26.26 35 24 35c-5.445 0-9.942-3.565-11.28-8.434l-6.519 5.025C9.505 39.556 16.227 43 24 43z"/><path fill="#1976D2" d="M43.611 20.083H42V20H24v8h11.303c-.867 2.476-2.504 4.549-4.616 5.974l6.19 5.238C42.012 36.021 45 30.555 45 24c0-1.295-.138-2.558-.389-3.917z"/></svg>
                  Continue with Google
                </button>
              </>
            )}

            {tab === 'forgot' && (
              <div className="text-center mt-3">
                <button onClick={() => setTab('login')} className="text-[13px] text-[#FFD700]/50 hover:text-[#FFD700] transition-colors">
                  ← Back to Login
                </button>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
        
        <div className="absolute -bottom-12 left-0 right-0 text-center">
          <button onClick={() => onNavigate('home')} className="text-[13px] text-white/30 hover:text-[#FFD700] transition-colors">
            ← Back to Vedank Music
          </button>
        </div>
      </motion.div>

    </div>
  );
}

import { auth } from "../firebase";
import { signOut } from "firebase/auth";

export default function Dashboard({ onNavigate }: { onNavigate: (p: string) => void }) {
  const handleLogout = async () => {
    await signOut(auth);
    onNavigate('home');
  };

  return (
    <div className="relative z-10 min-h-screen flex flex-col items-center justify-center p-4">
      <div className="p-12 text-center max-w-lg bg-white/5 border border-[#FFD700]/20 rounded-3xl backdrop-blur-xl shadow-[0_0_60px_rgba(255,215,0,0.06)]">
        <h1 className="font-display text-4xl mb-4 text-[#FFD700] drop-shadow-[0_0_20px_rgba(255,215,0,0.5)]">DASHBOARD</h1>
        <div className="font-[Orbitron] text-xl md:text-2xl tracking-[4px] bg-gradient-to-r from-[#FFD700] via-[#FF2020] to-[#FFD700] bg-[length:200%_100%] text-transparent bg-clip-text animate-[shimmer_3s_linear_infinite] my-8">
          WEBSITE UNDER MAINTENANCE
          <br/>
          COMING SOON
        </div>
        <button 
          onClick={handleLogout}
          className="mt-6 px-8 py-3 rounded-xl border border-white/10 text-white/50 hover:text-white hover:bg-white/5 transition-all text-sm tracking-widest font-[Orbitron]"
        >
          LOG OUT
        </button>
      </div>
    </div>
  );
}

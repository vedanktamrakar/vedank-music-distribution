import { motion } from "framer-motion";

export default function Home({ onNavigate }: { onNavigate: (p: string) => void }) {
  const streamingPlatforms = [
    { name: "Spotify", img: "/Spotify.gif" },
    { name: "Apple Music", img: "/Apple Music.gif" },
    { name: "YouTube", img: "/YouTube.gif" },
    { name: "Jio Saavan", img: "/Jio Saavan.gif" },
    { name: "Amazon Music", img: "/Amazon Music.gif" },
    { name: "Wynk", img: "/Wynk.gif" },
    { name: "Deezer", img: "/Deezer.gif" },
    { name: "Meta", img: "/Meta.gif" },
    { name: "Facebook", img: "/Facebook.gif" },
    { name: "Instagram", img: "/Instagram.gif" },
    { name: "Gaana", img: "/Gaana.png" },
    { name: "Snapchat", img: "/Snapchat.gif" },
    { name: "Hungama", img: "/Hungama.png" },
    { name: "Tik Tok", img: "/Tik Tok.gif" },
    { name: "Tidal", img: "/Tidal.gif" },
    { name: "Resso", img: "/Resso.png" },
    { name: "Qoboz", img: "/Qoboz.png" },
    { name: "Yendex Music", img: "/Yendex Music.gif" },
    { name: "Bomplay", img: "/Bomplay.png" },
    { name: "Vevo", img: "/Vevo.png" },
  ];

  const callerTunes = [
    { name: "Airtel", img: "/Airtel.gif" },
    { name: "JIO", img: "/Jio.png" },
    { name: "VI", img: "/VI.gif" },
    { name: "BSNL", img: "/BSNL.png" },
  ];

  return (
    <div className="relative z-10 w-full overflow-hidden min-h-screen">
      {/* Waveform Top Bar */}
      <div className="flex justify-center items-end gap-[3px] h-[70px] pt-[18px]">
        {Array.from({ length: 40 }).map((_, i) => (
          <motion.div
            key={i}
            animate={{ scaleY: [0.2, 1, 0.2] }}
            transition={{
              repeat: Infinity,
              duration: 0.8 + Math.random(),
              delay: (i / 40) * 1.5,
              ease: "easeInOut",
            }}
            className="w-1 rounded-full bg-gradient-to-t from-[#E8001E] to-[#FFD700] origin-bottom shadow-[0_0_6px_#FF2F2F]"
            style={{ height: `${15 + Math.random() * 55}px` }}
          />
        ))}
      </div>

      {/* Hero */}
      <section className="relative text-center px-4 pt-10 pb-5 min-h-[90vh] flex flex-col items-center justify-center">
        {/* Logo */}
        <div className="relative inline-block w-[200px] h-[200px] mb-8 animate-[logoFloat_5s_ease-in-out_infinite]">
          <div className="absolute -inset-12 rounded-full bg-radial from-[#FFD700]/15 to-transparent animate-[glowPulse_3s_infinite]" />
          
          <div className="w-[200px] h-[200px] rounded-full overflow-hidden shadow-[0_0_50px_rgba(255,215,0,0.3),0_0_100px_rgba(232,0,30,0.2)]">
             <img src="/Vedank Music.png" alt="Vedank Music" className="w-full h-full object-cover" />
          </div>
        </div>

        <motion.h1 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="font-display text-[clamp(52px,11vw,110px)] leading-[0.95] tracking-[4px]"
        >
          <span className="block text-[#FFD700] drop-shadow-[0_0_20px_#FFD700,0_0_60px_rgba(255,215,0,0.4)]">VEDANK</span>
          <span className="block text-[#FF2F2F] drop-shadow-[0_0_20px_#FF2F2F,0_0_60px_rgba(232,0,30,0.4)]">MUSIC</span>
        </motion.h1>

        <div className="inline-flex items-center gap-[10px] mt-4 px-[22px] py-2 rounded-full bg-gradient-to-br from-[#FFD700]/15 to-[#FFD700]/5 border border-[#FFD700]/30 font-[Orbitron] text-[11px] tracking-[4px] text-[#FFD700] shadow-[0_0_10px_rgba(255,215,0,0.2)]">
          <span className="w-2 h-2 rounded-full bg-[#FFD700] animate-[blink_1s_infinite]" />
          OFFICIAL ARTIST
          <span className="w-2 h-2 rounded-full bg-[#FFD700] animate-[blink_1s_infinite]" />
        </div>

        <div className="font-[Orbitron] text-[clamp(18px,3.5vw,36px)] tracking-[5px] mt-5 bg-gradient-to-r from-[#FFD700] via-[#FFA500] to-[#FF2F2F] bg-[length:300%_100%] text-transparent bg-clip-text animate-[shimmer_3s_linear_infinite]">
          MUSIC DISTRIBUTION — COMING SOON
        </div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-6"
        >
          <button 
            onClick={() => onNavigate('auth')}
            className="group relative inline-flex items-center justify-center px-8 py-3 font-[Orbitron] font-bold text-sm tracking-widest text-[#000] bg-gradient-to-r from-[#FFD700] to-[#FFA500] rounded-full overflow-hidden transition-transform hover:scale-105 hover:shadow-[0_0_40px_rgba(255,215,0,0.6)]"
          >
            <span className="absolute inset-0 w-full h-full bg-white/20 scale-x-0 group-hover:scale-x-100 origin-left transition-transform duration-300" />
            CREATE ACCOUNT FOR FREE
          </button>
        </motion.div>

      </section>

      {/* Marquee */}
      <div className="relative z-10 overflow-hidden py-4 border-y border-[#FFD700]/10 mb-4 bg-black/20 backdrop-blur-sm">
        <div className="flex gap-[60px] w-max animate-[marquee_22s_linear_infinite]">
          {Array.from({length: 4}).fill(0).map((_, i) => (
            <div key={i} className="flex gap-[60px]">
              <span className="font-display text-xl tracking-widest text-white/20">VEDANK MUSIC</span>
              <span className="font-display text-xl tracking-widest text-[#FFD700]/60">◆</span>
              <span className="font-display text-xl tracking-widest text-white/20">OFFICIAL DISTRIBUTION</span>
              <span className="font-display text-xl tracking-widest text-[#FFD700]/60">◆</span>
              <span className="font-display text-xl tracking-widest text-white/20">COMING SOON</span>
              <span className="font-display text-xl tracking-widest text-[#FFD700]/60">◆</span>
              <span className="font-display text-xl tracking-widest text-white/20">CALLER TUNES</span>
              <span className="font-display text-xl tracking-widest text-[#FFD700]/60">◆</span>
            </div>
          ))}
        </div>
      </div>

      {/* Streaming Platforms */}
      <section id="platforms" className="relative z-10 py-20 px-8 max-w-7xl mx-auto">
        <div className="absolute rounded-full filter blur-[80px] w-[400px] h-[400px] bg-[#FFD700]/5 -top-[100px] -left-[100px] pointer-events-none" />
        
        <div className="text-center mb-12">
          <h2 className="font-display text-[clamp(32px,6vw,60px)] tracking-[4px]">
            <span className="text-[#FFD700]">Streaming</span> <span className="text-[#FF2F2F]">Platforms</span>
          </h2>
          <div className="w-[120px] h-[2px] mx-auto mt-2 bg-gradient-to-r from-transparent via-[#FFD700] to-transparent" />
          <p className="mt-4 font-[Orbitron] text-sm tracking-[3px] text-white/40">YOUR MUSIC — EVERYWHERE</p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-5">
          {streamingPlatforms.map((p, i) => (
             <motion.div 
               key={i}
               initial={{ opacity: 0, y: 30 }}
               whileInView={{ opacity: 1, y: 0 }}
               whileHover={{ y: -8, scale: 1.04 }}
               whileTap={{ scale: 1.15, rotate: 6 }}
               viewport={{ once: true }}
               transition={{ duration: 0.3 }}
               className="group relative bg-white/5 border border-white/10 rounded-2xl p-5 text-center hover:border-[#FFD700]/30 hover:shadow-[0_20px_50px_rgba(0,0,0,0.5),0_0_30px_rgba(255,215,0,0.15)] overflow-hidden cursor-pointer"
             >
               <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-[#FFD700]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
               <img src={p.img} alt={p.name} className="relative z-10 w-20 h-20 object-contain mx-auto drop-shadow-[0_4px_12px_rgba(0,0,0,0.5)] transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3" 
                 onError={(e) => {
                   (e.target as HTMLImageElement).style.display = 'none';
                   e.currentTarget.parentElement!.innerHTML = `<div class="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#FFD700]/15 to-[#E8001E]/15 border border-[#FFD700]/25 flex items-center justify-center mx-auto font-display text-2xl text-[#FFD700]">${p.name[0]}</div>`;
                 }}
               />
               <h3 className="relative z-10 mt-3 text-[13px] font-semibold tracking-wide text-white/80">{p.name}</h3>
             </motion.div>
          ))}
        </div>
      </section>

      {/* Caller Tunes */}
      <section className="relative z-10 py-20 px-8 bg-gradient-to-b from-transparent via-[#FFD700]/5 to-transparent border-y border-[#FFD700]/10">
        <span className="absolute top-5 right-8 font-[Orbitron] text-[9px] tracking-[4px] text-[#FFD700]/40">◈ EXCLUSIVE</span>
        
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="font-display text-[clamp(32px,6vw,60px)] tracking-[4px] mb-2">
            <span className="text-[#FFD700]">Caller</span> <span>Tune</span> <span className="text-[#FF2F2F]">Services</span>
          </h2>
          <div className="w-[120px] h-[2px] mx-auto bg-gradient-to-r from-transparent via-[#FFD700] to-transparent" />
          <p className="mt-4 mb-10 font-[Orbitron] text-sm tracking-[3px] text-white/40">SET YOUR MUSIC AS A CALLER TUNE</p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {callerTunes.map((p, i) => (
              <motion.div 
               key={i}
               initial={{ opacity: 0, y: 30 }}
               whileInView={{ opacity: 1, y: 0 }}
               whileHover={{ y: -12, scale: 1.02 }}
               whileTap={{ scale: 1.1, rotate: -4 }}
               viewport={{ once: true }}
               transition={{ delay: i * 0.1, duration: 0.4 }}
               className="group relative bg-gradient-to-br from-[#FFD700]/5 to-[#FF2F2F]/5 border border-[#FFD700]/20 rounded-3xl p-8 text-center hover:border-[#FFD700]/50 hover:shadow-[0_25px_60px_rgba(0,0,0,0.6),0_0_40px_rgba(255,215,0,0.2)] overflow-hidden cursor-pointer"
              >
                <div className="absolute -bottom-16 left-1/2 -translate-x-1/2 w-[120px] h-[120px] rounded-full bg-radial from-[#FFD700]/20 to-transparent group-hover:-bottom-5 group-hover:opacity-80 transition-all duration-400" />
                <div className="absolute top-3 right-3 w-2 h-2 rounded-full bg-[#FFD700] drop-shadow-[0_0_8px_#FFD700] animate-[blink_1.5s_ease-in-out_infinite]" />
                
                <img src={p.img} alt={p.name} className="relative z-10 w-[90px] h-[90px] object-contain mx-auto drop-shadow-xl" 
                 onError={(e) => {
                   (e.target as HTMLImageElement).style.display = 'none';
                   e.currentTarget.parentElement!.innerHTML = `<div class="w-[90px] h-[90px] rounded-2xl bg-gradient-to-br from-[#FFD700]/15 to-[#E8001E]/15 border border-[#FFD700]/25 flex items-center justify-center mx-auto font-display text-4xl text-[#FFD700]">${p.name[0]}</div>`;
                 }}
                />
                <h3 className="relative z-10 mt-4 font-[Orbitron] text-base tracking-[2px] text-[#FFD700]">{p.name}</h3>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact / Email Footer */}
      <section id="contact-footer" className="relative z-10 pt-16 pb-8 px-8 text-center">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="max-w-2xl mx-auto bg-white/5 border border-[#FFD700]/20 rounded-[30px] p-12 relative overflow-hidden transition-all duration-400 hover:shadow-[0_0_60px_rgba(255,215,0,0.15)] hover:border-[#FFD700]/40 group"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-[#FFD700]/5 to-[#E8001E]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-400" />
          <div className="relative font-[Orbitron] text-[11px] tracking-[5px] text-white/40 mb-4">◈ BUSINESS INQUIRIES ◈</div>
          <div className="relative font-[Orbitron] text-sm text-white/50 tracking-[3px] mb-4">GET IN TOUCH</div>
          <a href="mailto:vedankmusic@proton.me" className="relative block font-display text-[clamp(22px,4vw,38px)] tracking-[2px] text-[#FFD700] drop-shadow-[0_0_20px_rgba(255,215,0,0.4)] hover:brightness-125 transition-all">
            vedankmusic@proton.me
          </a>
          <div className="relative mt-5 text-[12px] text-white/30 tracking-[2px]">FOR PARTNERSHIPS • DISTRIBUTION • COLLABORATIONS</div>
        </motion.div>
      </section>

      <footer className="relative z-10 text-center p-8 border-t border-white/5 text-xs text-white/25 tracking-[2px] font-[Orbitron]">
        <span className="text-[#FFD700]">VEDANK</span> <span className="text-[#FF2F2F]">MUSIC</span>
        &nbsp;•&nbsp; ALL RIGHTS RESERVED &nbsp;•&nbsp;
        <span className="text-[#FFD700]/50">OFFICIAL DISTRIBUTION</span>
      </footer>

    </div>
  );
}

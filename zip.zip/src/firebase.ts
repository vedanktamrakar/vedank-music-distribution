import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyDA1t6C0WZOwtjlC_-w0PFuwr0b-mAJEtQ",
  authDomain: "vedankmusic.firebaseapp.com",
  projectId: "vedankmusic",
  storageBucket: "vedankmusic.firebasestorage.app",
  messagingSenderId: "906382095261",
  appId: "1:906382095261:web:47950aa259df0687f73574",
  measurementId: "G-XBT50SJGPY"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

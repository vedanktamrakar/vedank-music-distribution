import { Menu, User, X } from "lucide-react";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface NavbarProps {
  onNavigate: (page: string) => void;
  user: any;
}

export default function Navbar({ onNavigate, user }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);

  const handleNav = (page: string) => {
    setIsOpen(false);
    if(page === 'contact') {
      onNavigate('home');
      setTimeout(() => {
        document.getElementById('contact-footer')?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
      return;
    }
    if(page === 'platforms') {
      onNavigate('home');
      setTimeout(() => {
        document.getElementById('platforms')?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
      return;
    }
    onNavigate(page);
  };

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 p-4 flex justify-between items-center bg-[#04020a]/80 backdrop-blur-md border-b border-[rgba(255,215,0,0.1)]">
        <button onClick={() => setIsOpen(true)} className="p-2 text-[#FFD700] hover:bg-[#FFD700]/10 rounded-lg outline-none transition-colors">
          <Menu className="w-6 h-6" />
        </button>
        <button 
          onClick={() => onNavigate(user ? 'dashboard' : 'auth')} 
          className="flex items-center gap-2 px-4 py-2 bg-white/5 border border-[#FFD700]/20 rounded-full text-xs font-[Orbitron] tracking-wider hover:bg-[#FFD700]/10 transition-all text-[#FFD700]"
        >
          <User className="w-4 h-4" />
          {user ? 'DASHBOARD' : 'ACCOUNT'}
        </button>
      </nav>

      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60]"
            />
            <motion.div 
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed top-0 left-0 bottom-0 w-[280px] bg-[#080415] border-r border-[#FFD700]/20 z-[70] p-6 shadow-2xl flex flex-col"
            >
              <div className="flex justify-between items-center mb-10">
                <div className="font-display text-2xl font-bold tracking-widest">
                  <span className="text-[#FFD700]">VEDANK</span> <span className="text-[#E8001E]">MUSIC</span>
                </div>
                <button onClick={() => setIsOpen(false)} className="text-white/50 hover:text-white transition-colors">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="flex flex-col gap-6 font-[Orbitron] tracking-widest text-sm text-white/70">
                <button onClick={() => handleNav('home')} className="text-left hover:text-[#FFD700] transition-colors">HOME</button>
                <button onClick={() => handleNav('features')} className="text-left hover:text-[#FFD700] transition-colors">FEATURES</button>
                <button onClick={() => handleNav('platforms')} className="text-left hover:text-[#FFD700] transition-colors">MUSIC PLATFORMS</button>
                <button onClick={() => handleNav('contact')} className="text-left hover:text-[#FFD700] transition-colors">CONTACT</button>
                
                <div className="h-px bg-white/10 my-2"></div>
                
                {user ? (
                  <button onClick={() => handleNav('dashboard')} className="text-left text-[#FFD700] hover:text-white transition-colors">DASHBOARD</button>
                ) : (
                  <>
                    <button onClick={() => handleNav('auth')} className="text-left text-[#FFD700] hover:text-white transition-colors">CREATE ACCOUNT</button>
                    <button onClick={() => handleNav('auth')} className="text-left hover:text-[#FFD700] transition-colors">LOGIN</button>
                  </>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
